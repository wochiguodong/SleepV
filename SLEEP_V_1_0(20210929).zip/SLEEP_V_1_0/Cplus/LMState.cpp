
#include "LMState.h"

LMState::LMState(cv::Mat frame, int nFRAME)
{
	//FrameBuffer = vectorQueue(frame, nFRAME);
	//bFrameBuffer = vectorQueue(frame, nFRAME);

	lFrameBuffer = new MatList(frame, nFRAME);
	lbFrameBuffer = new MatList(frame, nFRAME);
	// ��Ϣ��ʼ��
	lastLeftInfo.centerX = 25;
	lastLeftInfo.centerY = 25;
	lastLeftInfo.rt = cv::Rect(0, 0, 50, 50);
	lastLeftInfo.contour = vector<cv::Point>(0);
	lastLeftInfo.area = 2500;
	lastLeftInfo.predict01 = 0;
	lastLeftInfo.predict02 = 0;

	lastRightInfo.centerX = 25;
	lastRightInfo.centerY = 25;
	lastRightInfo.rt = cv::Rect(0, 0, 50, 50);
	lastRightInfo.contour = vector<cv::Point>(0);
	lastRightInfo.area = 2500;
	lastRightInfo.predict01 = 0;
	lastRightInfo.predict02 = 0;

	isLeftMouseLoss = false;
	isRightMouseLoss = false;
}

LMState::~LMState()
{
}
void LMState::getBinaryImage(cv::Mat& bImage, cv::Mat& aImage, cv::Mat& tImage)
{
	pbImg.copyTo(bImage);
	paImg.copyTo(aImage);
	ptImg.copyTo(tImage);
	//pbImg.copyTo(bImage);
}

void LMState::run(LM_FEATURE & leftFeature, LM_FEATURE & rightFeature)
{
	getMouseRect();
	getMouseFeature(leftInfo, leftFeature, isLeftMouseLoss);
	getMouseFeature(rightInfo, rightFeature, isRightMouseLoss);
	//if (!getMouseFeature(leftInfo, leftFeature, isLeftMouseLoss)) 
	//{
	//	cout << "Left Lossing" << endl;
	//};

	//if (!getMouseFeature(rightInfo, rightFeature, isRightMouseLoss)) 
	//{
	//	cout << "Right Lossing" << endl;
	//};

}

void LMState::updateFrame(cv::Mat frame)
{
	CTimeStat ts0, ts1;
	ts0.StartStat();
	ts1.StartStat();
	cv::Mat gImage;
	cvtColor(frame, gImage, cv::COLOR_BGR2GRAY);

	cv::Mat bImage, thImage, adImage, coImage;
	processImage(gImage, bImage, thImage, adImage, coImage);

	bImage.copyTo(pbImg);
	adImage.copyTo(paImg);
	thImage.copyTo(ptImg);
	//bImage.copyTo(pbImg);

	ts0.EndStat();
	lFrameBuffer->pop();
	lFrameBuffer->push(gImage);

	lbFrameBuffer->pop();
	lbFrameBuffer->push(bImage);
	ts1.EndStat();

	//cout << "STAGE1 TS: " << ts0.GetRunTime() << endl;
	//cout << "STAGE2 TS: " << ts1.GetRunTime() - ts0.GetRunTime() << endl;
}

// ��ȡFrameBufer�м�֡ͼ����С��λ������
void LMState::getMouseRect()
{
	int middle = lFrameBuffer->size();
	cv::Mat image = lFrameBuffer->middle();
	cv::Mat bimage = lbFrameBuffer->middle();
	//cv::imshow("output", bimage);
	//cv::waitKey(0);
	//// ����
	cv::Mat tmp;
	bimage.copyTo(tmp);
	vector<vector<cv::Point> > pContours;
	vector<cv::Vec4i> hierarchy;

	findContours(tmp, pContours, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_NONE, cv::Point(-1, -1));

	vector<LM_INFO> leftInfoTMP, rightInfoTMP;
	for (unsigned int i = 0; i < pContours.size(); i++) {
		vector<cv::Point> tmpC = pContours[i];

		double area = contourArea(tmpC);
		cv::Rect rt = boundingRect(tmpC);

		rt.x = max(rt.x, 0);
		rt.y = max(rt.y, 0);

		if (area < 800 | rt.width < 10 | rt.height < 10 |
			rt.width>bimage.cols/4 | rt.height>bimage.rows/4) {
			continue;
		}

		cv::Moments mt = cv::moments(tmpC);
		int center_x = int(mt.m10 / mt.m00);
		int center_y = int(mt.m01 / mt.m00);
		LM_INFO infoTmp;
		infoTmp.area = area;
		infoTmp.centerX = center_x;
		infoTmp.centerY = center_y;
		infoTmp.contour = tmpC;
		infoTmp.rt = rt;

		if (center_x < bimage.cols / 2)
		{
			leftInfoTMP.push_back(infoTmp);
			//cout << "LEFT++" << endl;
		}
		else {
			rightInfoTMP.push_back(infoTmp);
			//cout << "RIGHT++" << endl;
		}

	}

	// �ж�С���Ƿ��ڶ�ʧ״̬
	if (leftInfoTMP.size() < 1)	//��ʧ
	{
		leftInfo = lastLeftInfo;
		isLeftMouseLoss = true;
	}
	else
	{
		sort(leftInfoTMP.begin(), leftInfoTMP.end(), sortByArea);
		leftInfo = leftInfoTMP[0];
		lastLeftInfo = leftInfo;
		isLeftMouseLoss = false;
	}
	if (rightInfoTMP.size() < 1)	//��ʧ
	{
		rightInfo = lastRightInfo;
		isRightMouseLoss = true;
	}
	else
	{
		sort(rightInfoTMP.begin(), rightInfoTMP.end(), sortByArea);
		rightInfo = rightInfoTMP[0];
		lastRightInfo = rightInfo;
		isRightMouseLoss = false;
	}
	rightInfoTMP.clear();
	leftInfoTMP.clear();
};

cv::Mat LMState::showDetect() {

	cv::Mat showImage = lFrameBuffer->middle();
	cvtColor(showImage, showImage, cv::COLOR_GRAY2BGR);

	// ���ƾ��ο��
	rectangle(showImage, leftInfo.rt, cv::Scalar(255, 0, 0), 4);
	rectangle(showImage, rightInfo.rt, cv::Scalar(0, 255, 0), 4);

	return showImage;
}

bool LMState::getMouseFeature(LM_INFO mouseInfo, LM_FEATURE& lmFeature, bool isLoss) {
	/*
	* ��������N֡��Ƶͼ�񣬻�ȡ���ڱ����м�֡С����Ϣ������
	* �������� ��ɫ��ֵ��IOU��ֵ���߽����ƶȡ�Ԥ���
	*/

	/* Ŀǰ�ݶ�ֻ���Ŀ����������ͨ�� */


	if (isLoss) {
		lmFeature.colorErr = -1;
		lmFeature.iouErr = -1;
		lmFeature.similarityErr = -1;
		lmFeature.centerX = -1;
		lmFeature.centerY = -1;
		return false;
	}

	LM_INFO lmInfo = mouseInfo;
	double colorErr[NFRAME];
	double simErr[NFRAME];
	double iouErr[NFRAME];

	vector<cv::Mat> subFrames, subBinaryFrames;

	getSubImages(lmInfo, lFrameBuffer, subFrames);
	getSubImages(lmInfo, lbFrameBuffer, subBinaryFrames);	// ����λ�ã���ȡһЩ����ͼ

	cv::Mat middleImage = lFrameBuffer->middle();
	cv::Mat binaryMiddleImage(middleImage.rows, middleImage.cols, CV_8UC1, cv::Scalar(0));
	if (lmInfo.contour.size() <= 5) {
		/*������Ϊ��ʼ��ʧ�ܵ�ԭ��*/
		cout << "LMINFO_CONTOUR " << lmInfo.contour.size() << endl;
		return false;
	}

	vector<vector<cv::Point>> tmp;
	tmp.push_back(lmInfo.contour);
	drawContours(binaryMiddleImage, tmp, 0, cv::Scalar(255), -1);
	cv::Mat subBinaryMiddleImage = binaryMiddleImage(lmInfo.rt);			// �м���ͼ
	cv::Mat subMiddleImage = middleImage(lmInfo.rt);						// �м��ֵ��ͼ
	// ��������ֵ
	//cout << "**************" << subFrames.size() /*<*/< endl;
	caculateColorErr(subMiddleImage, subFrames, colorErr);
	caculateSimErr(subBinaryMiddleImage, subBinaryFrames, simErr, iouErr);

	// ������ֵ
	double maxcololerr = -1;
	int cnt = 0;
	for (unsigned int j = 0; j < NFRAME; j++) {
		//cout << colorErr[j] << endl;
		if (colorErr[j] > maxcololerr)
		{
			maxcololerr = colorErr[j];
			cnt = j;
		}
	}

	//cv::imshow("bimg", subMiddleImage);
	//cv::imshow("img", subBinaryMiddleImage);

	lmFeature.colorErr = colorErr[cnt];
	lmFeature.iouErr = iouErr[cnt];
	lmFeature.similarityErr = simErr[cnt];
	lmFeature.centerX = lmInfo.centerX;
	lmFeature.centerY = lmInfo.centerY;

	subFrames.clear();
	subBinaryFrames.clear();
	return true;
}
