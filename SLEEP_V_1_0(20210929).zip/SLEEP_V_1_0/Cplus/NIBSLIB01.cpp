// NIBSLIB01.cpp : Defines the exported functions for the DLL.
//

#define EXPORT __declspec(dllexport)
#include<fstream>
#include<iostream>
#include"LMState.h"
#include"FileAssist.h"

using namespace std;

class NIBSLIB01 {
public:
	// ������������ʱ��
    void extractLMFeature(string avi_path, string txt_save, string drawAVI_path, string isDraw);
};

void NIBSLIB01::extractLMFeature(string avi_path, string txt_save_dir, string drawAVI_path, string isDraw) {
    cv::VideoCapture capture;
    cv::Mat frame;
    CTimeStat ts;

    ts.StartStat();
    frame = capture.open(avi_path);
    if (!capture.isOpened())
    {
        printf("can not open ...\n");
    }
    // ������Ϣ
    bool flag = capture.read(frame);
    //cv::resize(frame, frame, cv::Size(frame.cols / 2, frame.rows / 2));

    string leftSaveTxt, rightSaveTxt;
    char pchName[256];
    CropStringByHeadTail((char*)(avi_path.c_str()), '\\', '.', pchName);

    //��ȡ��Ƶ����
    string spchName = pchName;
    leftSaveTxt = spchName + "_left.txt";
    rightSaveTxt = spchName + "_right.txt";
    //д�ļ�
    ofstream leftOutList(txt_save_dir + "\\" + leftSaveTxt);
    ofstream rightOutList(txt_save_dir + "\\" + rightSaveTxt);

    cv::VideoWriter writer1, writer2;
    if (isDraw == "TRUE") {
        string out_avi1, out_avi2;
        //��ȡ��Ƶ����
        out_avi1 = drawAVI_path + "\\" + spchName + "_src.avi";
        out_avi2 = drawAVI_path + "\\" + spchName + "_th.avi";

        writer1.open(out_avi1, writer1.fourcc('X', 'V', 'I', 'D'), 25, frame.size(), true);
        writer2.open(out_avi2, writer2.fourcc('X', 'V', 'I', 'D'), 25, frame.size(), true);
    }
    

    bool BUFFER_FULL = false;
    int step = 25;

    LMState lm(frame, NFRAME);
    int cnt = 0;
    cv::Point lastLeftMousePt(0, 0);
    cv::Point lastRightMousePt(0, 0);
    while (flag)
    {
        if (!BUFFER_FULL) {
            std::cout << "Init buffer!" << endl;
            for (unsigned int i = 0; i < NFRAME; i++) {
                lm.updateFrame(frame);
                flag = capture.read(frame);
                if (!flag)
                    break;
                //cv::resize(frame, frame, cv::Size(frame.cols / 2, frame.rows / 2));                
                cnt += 1;
            }
            BUFFER_FULL = true;
        }

        if (step != 25)
        {
            lm.updateFrame(frame);
            flag = capture.read(frame);
            if (!flag)
                break;
            //cv::resize(frame, frame, cv::Size(frame.cols / 2, frame.rows / 2));
            step += 1;
            cnt += 1;
            continue;
        }
        ////����
        step = 0;

        double colorErrLeft, simErrLeft, iouErrLeft;
        double colorErrRight, simErrRight, iouErrRight;

        LM_FEATURE leftMouseFeature, rightMouseFeature;

        lm.run(leftMouseFeature, rightMouseFeature);

        double leftDistance = myistance(lastLeftMousePt, cv::Point(leftMouseFeature.centerX, leftMouseFeature.centerY));
        double rightDistance = myistance(lastRightMousePt, cv::Point(rightMouseFeature.centerX, rightMouseFeature.centerY));

        lastLeftMousePt.x = leftMouseFeature.centerX;
        lastLeftMousePt.y = leftMouseFeature.centerY;
        lastRightMousePt.x = rightMouseFeature.centerX;
        lastRightMousePt.y = rightMouseFeature.centerY;
        //lastLeftMousePt = cv::Point(rightMouseFeature.centerX, rightMouseFeature.centerY);
        if (cnt == 25) {
            leftDistance = 0;
            rightDistance = 0;
        }

        cv::Mat show = lm.showDetect();
        //////cv::imshow("show", show);
        //////cv::waitKey(10);
        cv::Mat bImg, aImg, tImg, sImg;
        lm.getBinaryImage(bImg, aImg, tImg);
        cv::cvtColor(tImg, tImg, cv::COLOR_GRAY2BGR);

        leftMouseFeature.similarityErr = min(leftMouseFeature.similarityErr, 5);
        rightMouseFeature.similarityErr = min(rightMouseFeature.similarityErr, 5);
        //printf("Left: %.2f %5.6f %5.6f %5.6f\n",
        //    leftDistance, leftMouseFeature.colorErr, leftMouseFeature.iouErr, leftMouseFeature.similarityErr);
        //printf("Right: %.2f %5.6f %5.6f %5.6f\n",
        //    rightDistance, rightMouseFeature.colorErr, rightMouseFeature.iouErr, rightMouseFeature.similarityErr);
        char lFile[256];
        sprintf_s(lFile, 256, "%.2f %5.6f %5.6f %5.6f\n",
            leftDistance, leftMouseFeature.colorErr, leftMouseFeature.iouErr, leftMouseFeature.similarityErr);
        leftOutList << lFile;

        char rFile[256];
        sprintf_s(rFile, 256, "%.2f %5.6f %5.6f %5.6f\n",
            rightDistance, rightMouseFeature.colorErr, rightMouseFeature.iouErr, rightMouseFeature.similarityErr);
        rightOutList << rFile;

        if (isDraw == "TRUE") {
            //cout << "...." << endl;
            writer1.write(show);
            writer2.write(tImg);
        }

    }

    leftOutList.close();
    rightOutList.close();
    capture.release();

    if (isDraw == "TRUE") {
        writer1.release();
        writer2.release();
    }

    ts.EndStat();
}


extern "C" {
    NIBSLIB01 NL;
    EXPORT void eMFeature(char* str1, char* str2, char* str3, char* str4) {
        string s1(str1);
        string s2(str2);
        string s3(str3);
        string s4(str4);

        NL.extractLMFeature(s1, s2, s3, s4);
    }
}

