
#ifndef LMSTATE_
#define LMSTATE_

#include<opencv.hpp>
#include<iostream>
#include <algorithm>
#include <vector>
#include "TimeStat.h"
#include "MatList.h"
#include "imgproc.h"

//using namespace cv;
using namespace std;

class LMState
{
public:
	LMState(cv::Mat frame, int nFRAME);
	~LMState();

	void updateFrame(cv::Mat frame);		// ���´洢
	void run(LM_FEATURE& leftFeature, LM_FEATURE& rightFeature);
	cv::Mat showDetect();
	void getBinaryImage(cv::Mat& bImage, cv::Mat& aImage, cv::Mat& tImage);

private:
	LM_INFO lastLeftInfo, lastRightInfo;
	LM_INFO leftInfo, rightInfo;

	LM_FEATURE lastLeftFeature, lastRightFeature;
	LM_FEATURE leftFeature, rightFeature;

	//vectorQueue FrameBuffer;		// �洢NFrame
	//vectorQueue bFrameBuffer;		// �洢��ֵͼ���NFrame

	MatList* lFrameBuffer;
	MatList* lbFrameBuffer;
	

	bool isLeftMouseLoss = false;
	bool isRightMouseLoss = false;

	void getMouseRect();
	bool getMouseFeature(LM_INFO mouseInfo, LM_FEATURE& rightFeature, bool isLoss);

	cv::Mat pbImg, ptImg, paImg;

};

#endif