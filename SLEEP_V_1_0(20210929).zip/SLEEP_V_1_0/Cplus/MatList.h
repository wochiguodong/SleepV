#ifndef MATLIST_
#define MATLIST_

#include <iostream>
#include <sstream>
#include <string>
#include <ostream>
#include <iterator>
#include "myExceptions.h"
#include<opencv.hpp>

using namespace std;
#define NFRAME 25

//�����ڵ�
class MatNode
{
public:
    MatNode(cv::Mat tE);
    ~MatNode() { tElement.release(); }
    cv::Mat Element() const { return tElement; }
    MatNode* next;
private:
    cv::Mat tElement; //����ָʾ��ǰ�ڵ�
};


class MatList
{
public:
    //MatList();
    MatList(cv::Mat frame, int len);
    ~MatList();
    void push(cv::Mat img);//����
    cv::Mat middle();//����
    cv::Mat getIndex(int i);
    bool pop();
    int size();

protected:

private:
    MatNode* head;
};

#endif