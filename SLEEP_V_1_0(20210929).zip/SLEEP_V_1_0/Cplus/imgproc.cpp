#include "imgproc.h"

bool sortByArea(LM_INFO info1, LM_INFO info2)
{
	return info1.area > info2.area;
}

bool sortBySim(cv::Vec2d info1, cv::Vec2d info2) {
	return (info1[0] > info2[0]);
}

void getSubImages(LM_INFO lmInfo, MatList* images, vector<cv::Mat>& sImages) {
	for (unsigned int i = 0; i < images->size(); i++) {
		cv::Mat timg = images->getIndex(i);
		sImages.push_back(timg(lmInfo.rt));
	}
}

double IOU(cv::Mat imageGround, cv::Mat image)
{
	//��ʼ������������
	double dunion = 0.0;
	double dpositive1 = 0.0;
	double dpositive2 = 0.0;
	double dintersection = 0.0;
	double diou = 0.0;

	for (int i = 0; i < imageGround.cols; i++)
	{
		for (int j = 0; j < imageGround.rows; j++)
		{
			//���㽻��
			if ((imageGround.at<uchar>(j, i) == 255) && (image.at<uchar>(j, i) == 255))
				dintersection = dintersection + 1.0;
			//����groundtruth��������ռ�����ظ���
			if (image.at<uchar>(j, i) == 255)
				dpositive1 = dpositive1 + 1.0;
			//����ָ�ͼ��õ�����������ظ���
			if (imageGround.at<uchar>(j, i) == 255)
				dpositive2 = dpositive2 + 1.0;
		}
	}
	//���㲢��������Groundtruth������ָ�������֮�ͣ��ټ�ȥ����
	dunion = dpositive1 + dpositive2 - dintersection;
	diou = (double)(dintersection / dunion); //�����ֵ

	return diou; //���
}

void caculateColorErr(cv::Mat img, vector<cv::Mat> subImages, double colorErr[]) {
	for (unsigned int i = 0; i < subImages.size(); i++) {
		cv::Mat err;
		absdiff(img, subImages[i], err);
		cv::Scalar sErr = sum(err);

		double cErr = (sErr[0] + sErr[1] + sErr[2]) / (err.cols * err.rows);
		//cout << "ColorERR: " << sErr[0] << sErr[1] << sErr[2] << endl;
		colorErr[i] = cErr;
	}
}

void caculateSimErr(cv::Mat bimg, vector<cv::Mat> subBinaryImages, double simErr[], double iouErr[]) {

	cv::Mat bbimg, bsubBinaryImage;
	copyMakeBorder(bimg, bbimg, 2, 2, 2, 2, cv::BORDER_CONSTANT, cv::Scalar(0));
	// ��ͨ��
	cv::Mat tmp1, tmp2;
	bimg.copyTo(tmp1);
	vector<vector<cv::Point> > pContours1;
	vector<cv::Vec4i> hierarchy1;
	findContours(tmp1, pContours1, hierarchy1, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_NONE, cv::Point(-1, -1));

	// ����Ŀ��ͼ���basecontour
	vector<cv::Point> baseContours;
	if (pContours1.size() > 1) {
		// �������ǲ�Ӧ�õ�
		cout << "This is an UNKONW ERROR 001!!!" << endl;
	}
	else if (pContours1.size() == 0)
	{
		// �������ǲ�Ӧ�õ�
		cout << "This is an UNKONW ERROR 002!!!" << endl;
	}
	else {
		baseContours = pContours1[0];
	}

	for (unsigned int i = 0; i < subBinaryImages.size(); i++) {
		copyMakeBorder(subBinaryImages[i], bsubBinaryImage, 2, 2, 2, 2, cv::BORDER_CONSTANT, cv::Scalar(0));
		bsubBinaryImage.copyTo(tmp2);
		vector<vector<cv::Point> > pContours2;
		vector<cv::Vec4i> hierarchy2;
		findContours(tmp2, pContours2, hierarchy2, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_NONE, cv::Point(-1, -1));

		if (pContours2.size() > 1) {
			vector<cv::Vec2d> ErrTMP;
			//cout << "====================" << endl;
			for (unsigned int j = 0; j < pContours2.size(); j++) {
				cv::Mat drawBimg = cv::Mat(bsubBinaryImage.rows, bbimg.cols, CV_8UC1, cv::Scalar(0));
				drawContours(drawBimg, pContours2, j, cv::Scalar(255), cv::FILLED);

				double simE = matchShapes(baseContours, pContours2[j], 1, 0.0);
				double iouE = IOU(bbimg, drawBimg);

				ErrTMP.push_back(cv::Vec2d(simE, iouE));
			}
			sort(ErrTMP.begin(), ErrTMP.end(), sortBySim);

			simErr[i] = ErrTMP[0][0];
			iouErr[i] = 1 - ErrTMP[0][1];

			ErrTMP.clear();
		}
		else if (pContours2.size() == 0)
		{
			simErr[i] = 10.0;
			iouErr[i] = 1.0;
		}
		else {
			cv::Mat drawBimg = cv::Mat(bsubBinaryImage.rows, bbimg.cols, CV_8UC1, cv::Scalar(0));
			drawContours(drawBimg, pContours2, 0, cv::Scalar(255), cv::FILLED);
			//cv::imshow("test", drawBimg);
			//cv::waitKey(0);
			double simE = matchShapes(baseContours, pContours2[0], 1, 0.0);
			double iouE = IOU(bbimg, drawBimg);

			simErr[i] = simE;
			iouErr[i] = 1 - iouE;
		}
	}
}

void imageResize(cv::Mat src, cv::Mat& dst, cv::Size s) {
	int src_h = src.rows; //height
	int src_w = src.cols;//width
	int out_h = s.height, out_w = s.width;
	cv::Mat dst_mat = cv::Mat::zeros(out_h, out_w, CV_8UC1);

	for (int j = 0; j < out_h; j++) {
		uchar* data = dst_mat.ptr<uchar>(j);
		for (int i = 0; i < out_w; i++) {
			int raw_w = int(i * (double(src_w) / out_w)), raw_h = j * (double(src_h) / out_h);
			data[i] = src.at<uchar>(raw_h, raw_w);
		}
	}

	dst_mat.copyTo(dst);

}

void processImage(cv::Mat& image, cv::Mat& binaryImage, cv::Mat& thresholdImage, cv::Mat& adapthImage, cv::Mat& colorImage)
{
	cv::Mat img, bImg, tImg, aImg, cImg;
	image.copyTo(img);

	int hh, ww;
	hh = img.rows;
	ww = img.cols;

	cv::Mat	gaussImage;
	GaussianBlur(img, gaussImage, cv::Size(5, 5), 0);

	cvtColor(gaussImage, cImg, cv::COLOR_GRAY2BGR);

	double th;
	th = threshold(gaussImage, tImg, 80, 255, cv::THRESH_BINARY);

	cv::Mat resizeImage;
	cv::resize(gaussImage, resizeImage, cv::Size(img.cols / 2, img.rows / 2));
	adaptiveThreshold(resizeImage, aImg, 255, cv::ADAPTIVE_THRESH_GAUSSIAN_C, cv::THRESH_BINARY, 101, 20);

	cv::Mat kernel1(5, 5, CV_8U, cv::Scalar(1));
	morphologyEx(tImg, tImg, cv::MORPH_CLOSE, kernel1, cv::Point(-1, -1), 1);
	morphologyEx(aImg, aImg, cv::MORPH_CLOSE, kernel1, cv::Point(-1, -1), 1);
	imageResize(aImg, aImg, cv::Size(img.cols, img.rows));

	bitwise_and(255 - tImg, 255 - aImg, bImg);
	cv::morphologyEx(bImg, bImg, cv::MORPH_CLOSE, kernel1, cv::Point(-1, -1), 1);

	// ʹ����ͨ����˹��� ������ֵͼ��
	cv::Mat tmp;
	bImg.copyTo(tmp);
	vector<vector<cv::Point> > pContours;
	vector<cv::Vec4i> hierarchy;

	cv::findContours(tmp, pContours, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_NONE, cv::Point(-1, -1));
	vector<LM_INFO> leftInfoTMP, rightInfoTMP;
	for (unsigned int i = 0; i < pContours.size(); i++) {
		vector<cv::Point> tmpC = pContours[i];

		double area = contourArea(tmpC);
		cv::Rect rt = boundingRect(tmpC);

		if (area < 800 | rt.width < 10 | rt.height < 10) {
			drawContours(bImg, pContours, i, cv::Scalar(0), -1);
			continue;
		}
		drawContours(bImg, pContours, i, cv::Scalar(255), -1);
	}
	morphologyEx(bImg, bImg, cv::MORPH_OPEN, kernel1, cv::Point(-1, -1), 1);

	bImg.copyTo(binaryImage);
	aImg.copyTo(adapthImage);
	tImg.copyTo(thresholdImage);
	cImg.copyTo(colorImage);
}

double myistance(cv::Point a, cv::Point b) {
	return sqrt(pow(a.x - b.x, 2) + pow(a.y - b.y, 2));
}