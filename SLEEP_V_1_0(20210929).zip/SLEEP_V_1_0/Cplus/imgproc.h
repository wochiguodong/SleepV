#ifndef IMGPROC_
#define IMGPROC_

#include<opencv.hpp>
#include<iostream>
#include <algorithm>
#include<vector>
#include "MatList.h"

// ����С��λ����Ϣ
typedef struct LM_INFO
{
	int centerX;
	int centerY;
	vector<cv::Point> contour;
	cv::Rect rt;
	int predict01;
	int predict02;
	double area;		// �����С
};


// С��������Ϣ
typedef struct LM_FEATURE
{
	double colorErr;

	int centerX;
	int centerY;
	int width;
	int hight;

	double similarityErr;
	double iouErr;
	double predictErr;
};

bool sortByArea(LM_INFO info1, LM_INFO info2);

bool sortBySim(cv::Vec2d info1, cv::Vec2d info2);

void getSubImages(LM_INFO lmInfo, MatList* images, vector<cv::Mat>& sImages);

double IOU(cv::Mat imageGround, cv::Mat image);

void caculateColorErr(cv::Mat img, vector<cv::Mat> subImages, double colorErr[]);

void caculateSimErr(cv::Mat bimg, vector<cv::Mat> subBinaryImages, double simErr[], double iouErr[]);

void imageResize(cv::Mat src, cv::Mat& dst, cv::Size s);

void processImage(cv::Mat& image, cv::Mat& binaryImage, cv::Mat& thresholdImage, cv::Mat& adapthImage, cv::Mat& colorImage);

double myistance(cv::Point a, cv::Point b);

#endif