/*
	+ ******************************************************************
	����:	����ָ��ģ������ʱ��
	����:	Lonkil
	����:	lonkil_at_gmail.com
	��վ:	www.vcfans.com
	����:	2008-07-25
	- ******************************************************************
*/

#if !defined(AFX_TIMESTAT_H__438A052D_09B6_4DEC_B1DD_1968B54742E4__INCLUDED_)
#define AFX_TIMESTAT_H__438A052D_09B6_4DEC_B1DD_1968B54742E4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <Windows.h>
#include <vector>

using namespace std;

#define TS_STONE_MAX 100

typedef struct{
	char    pchFuncName[256];
	float   fTimeCost;
}FUNC_TIME_STAT;

class CTimeStat  
{
public:
	CTimeStat();
	virtual ~CTimeStat();
	int		idx;
	void	StartStat();//��ʼͳ��
	void	EndStat();//����ͳ��
	double	GetRunTime();//ȡ������ʱ��
	void	GetFuncTime( char pchFuncName[]);
	float   PrintfTimeList();

	//
	void    SetTimeStone(int idx);

	//
	vector<FUNC_TIME_STAT>  m_vtTimeStat;
public:
	LONGLONG _CurTime();
public:
	LONGLONG				m_llTimeStart;
	LONGLONG				m_llTimeEnd;
	double					m_fTimeEscape;
	LONGLONG				m_llCountPreSecond;
	FILE*	                m_pLog;

	//
	int     m_nStoneCount;
	float	m_pTimeStone[TS_STONE_MAX];

	//
	int     m_nFrameIdx;
};


#endif // !defined(AFX_TIMESTAT_H__438A052D_09B6_4DEC_B1DD_1968B54742E4__INCLUDED_)
