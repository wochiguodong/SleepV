
#include "MatList.h"
#pragma warning(disable:4996)

MatNode::MatNode(cv::Mat tE)
{
    tE.copyTo(tElement);
    next = NULL;
}

// ����ͼ������
MatList::MatList(cv::Mat frame, int len) {
    MatNode* p = new MatNode(frame);
    head = p;

    for (int i = 0; i < len - 1; i++) {
        MatNode* tmp = new MatNode(frame);
        //cout << tmp->next << endl;
        p->next = tmp;
        p = p->next;
    }
}

MatList::~MatList()
{
    MatNode* p = head;
    MatNode* pp;
    while (p->next != NULL)
    {
        pp = p;
        p = p->next;
        delete pp;
    }
}

// β������
void MatList::push(cv::Mat img)
{
    MatNode* node = new MatNode(img);
    MatNode* p = head;
    while (p->next != NULL)
        p = p->next;
    p->next = node;
}

// ͷ��ɾ��
bool MatList::pop()
{
    if (head == NULL)
    {
        return NULL;
    }

    MatNode* p = head;
    head = head->next;
    delete p;
}

// ����
int MatList::size()
{
    int cnt = 1;
    MatNode* p = head;
    //cout << &head << endl;
    //cout << p->Element().cols << endl;
    while (p->next != NULL)
    {
        p = p->next;
        cnt += 1;
    }

    return cnt;
}

cv::Mat MatList::middle()
{
    int ss = size();
    int mid = 0;
    MatNode* p = head;

    while (mid != int((ss - 1) / 2)) {
        p = p->next;
        mid += 1;
    }
    return p->Element();
}

cv::Mat MatList::getIndex(int i)
{
    //int ss = size();

    if (i == 0)
        return head->Element();

    int idx = 0;
    MatNode* p = head;
    while (idx != i)
    {
        p = p->next;
        idx += 1;
    }
    return p->Element();
}
