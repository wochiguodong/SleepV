
#ifndef VECTORQUEUE_
#define VECTORQUEUE_

#pragma once
#include <iostream>
#include <sstream>
#include <string>
#include <ostream>
#include <vector>
#include <iterator>
#include "myExceptions.h"
#include <opencv.hpp>

using namespace std;
//using namespace cv;

class vectorQueue
{
public:
     vectorQueue(cv::Mat frame, int initLenth);
     vectorQueue();
     ~vectorQueue();
     bool empty() const;
     int size() const;
     cv::Mat & front();
     cv::Mat & back();
     cv::Mat & middle();
     void pop();
     void push(const cv::Mat & theElement);
     void output(std::ostream & out);
     cv::Mat& getIndex(int i);
protected:
     //vector<Mat> * element;
     vector<cv::Mat> element;
 };

vectorQueue::vectorQueue() {

}

vectorQueue::vectorQueue(cv::Mat frame, int initLenth)
{
     if (0 >= initLenth)
     {
         std::ostringstream s;
         s << "initLenth = " << initLenth << "must > 0" << endl;
         throw illegalParameterValue(s.str());
     }

     for (unsigned int i = 0; i < initLenth; i++) {
         element.push_back(frame);
     }

     //element = new vector<Mat>[initLenth];
     //ele = new vector<Mat>[25];
     //cout<<(*element).size()<<" "<<initLenth<<endl;
     cout<< element.size()<<" "<<initLenth<<endl;
}

vectorQueue::~vectorQueue()
{
    element.clear();
 }

bool vectorQueue::empty() const
{
     return element.empty();
 }

int vectorQueue::size() const
{
     return element.size();
}

cv::Mat & vectorQueue::front()
{
     if (element.begin() == element.end())
         throw queueEmpty();
     return element[0];
}

cv::Mat & vectorQueue::getIndex(int i)
{
    if (i < 0 or i >= element.size()) {
        throw queueEmpty();
    }
    return element[i];
}

cv::Mat & vectorQueue::back()
{
     return element[element.size()-1];
}

cv::Mat & vectorQueue::middle()
{
     return element[int(element.size()-1)/2];

}

void vectorQueue::pop()
{
     if (element.empty())
         throw queueEmpty();
     element.erase(element.begin());
}

void vectorQueue::push(const cv::Mat & theElement)
{
     element.push_back(theElement);
}

#endif