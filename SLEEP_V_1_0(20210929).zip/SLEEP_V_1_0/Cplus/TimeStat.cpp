/*
	+ ******************************************************************
	����:	����ָ��ģ������ʱ��
	����:	Lonkil
	����:	lonkil_at_gmail.com
	��վ:	www.vcfans.com
	����:	2008-07-25
	- ******************************************************************
*/

#include "TimeStat.h"
#include "mmsystem.h"
#pragma comment(lib,"winmm.lib")
#pragma warning(disable:4996)
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTimeStat::CTimeStat()
{
	LARGE_INTEGER lager_int;
	m_llTimeStart = m_llTimeEnd = 0;
	m_fTimeEscape = 0.0f;
	if ( QueryPerformanceFrequency(&lager_int) )
	{
		m_llCountPreSecond = lager_int.QuadPart;//��ȡʱ��Ƶ��
	}
	else
	{
		m_llCountPreSecond = 0;
	}
	idx = 0;

	//
	m_pLog = NULL;

	//
	memset(this->m_pTimeStone , 0 , sizeof(float)*TS_STONE_MAX);

	//
	m_nFrameIdx = 0;
}

CTimeStat::~CTimeStat()
{
	if(m_pLog != NULL)
	{
		fclose(m_pLog);
	}
}

void CTimeStat::StartStat()//��ʼͳ��
{
	m_llTimeStart = _CurTime();
}

void CTimeStat::EndStat()//����ͳ��
{
	m_llTimeEnd = _CurTime();
}

void CTimeStat::SetTimeStone(int idx)
{
	this->m_pTimeStone[idx] = (float)(_CurTime());

	//
	this->m_nStoneCount = idx;
}

double CTimeStat::GetRunTime()//ȡ������ʱ��
{
	double dwSpan;
	if( m_llCountPreSecond != 0 )
	{
		dwSpan = (double)( m_llTimeEnd - m_llTimeStart );
		dwSpan /= m_llCountPreSecond;//ִ�е�����	
		dwSpan *= 1000.0f;//ִ�еĺ�����
	}
	else
	{
		dwSpan = (double)( m_llTimeEnd - m_llTimeStart );
	}
	return dwSpan;
}

void CTimeStat::GetFuncTime( char pchFuncName[])//ȡ������ʱ��
{
	double dwSpan;

	this->EndStat();

	if( m_llCountPreSecond != 0 )
	{
		dwSpan = (double)( m_llTimeEnd - m_llTimeStart );
		dwSpan /= m_llCountPreSecond;//ִ�е�����	
		dwSpan *= 1000.0f;//ִ�еĺ�����
	}
	else
	{
		dwSpan = (double)( m_llTimeEnd - m_llTimeStart );
	}

	FUNC_TIME_STAT stFuncTime;
	strcpy(stFuncTime.pchFuncName , pchFuncName);
	stFuncTime.fTimeCost = (float)dwSpan;
	this->m_vtTimeStat.push_back(stFuncTime);

	return ;
}

float CTimeStat::PrintfTimeList()
{
	int		i;
	float	fTimeTotal = 0;
	if( this->m_vtTimeStat.size() > 0)
	{
		for( i = 0 ; i < this->m_vtTimeStat.size() ; i++)
		{
			fTimeTotal += this->m_vtTimeStat[i].fTimeCost;
			printf("[%2d]:%20s %.1f\n" , i , this->m_vtTimeStat[i].pchFuncName , this->m_vtTimeStat[i].fTimeCost);
		}
	}
	else
	{
		printf("\n");
	}
	printf("***********************[%d]total time [%.1f]*************************\n" , idx , fTimeTotal);
	this->m_vtTimeStat.clear();
	return fTimeTotal;
}

//�õ�ǰʱ��
LONGLONG CTimeStat::_CurTime()
{
	LONGLONG llCount;
	LARGE_INTEGER ll_Int;
	if( (0 != m_llCountPreSecond) && QueryPerformanceCounter(&ll_Int) )
	{
		llCount = ll_Int.QuadPart;
	}
	else
	{//���������֧�ָ߾��ȼ�ʱ�����Ͳ��ö�ý���ʱ��
		llCount = (LONGLONG)timeGetTime();
	}
	return llCount;
}
