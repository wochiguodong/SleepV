"""
author:shuai.zhao
function: 睡眠分析
"""

import numpy as np

def get_sleep_list(sleep_list, cfg):
    """
    :param distance: 位移序列
    :return: 睡眠时间段
    """
    SHORT_TM_SLEEP = int(cfg["SHORT_TM_SLEEP"])  ## 短睡眠
    CC = int(cfg["CC"])  ##　抽搐

    SHORT_TM_STAY = 3

    ## 重新定义 distance
    sleep_list_ = sleep_list.copy()
    
    # 抽搐    原始睡眠数据  去除抽搐后的睡眠
    cc_list, sleep_short_period, sleep_short_period_wo_cc = get_cc_period(sleep_list_, SHORT_TM_STAY, CC)

    sleep_final = \
        filter_cc_preiod(sleep_short_period_wo_cc,SHORT_TM_SLEEP=SHORT_TM_SLEEP)
    return sleep_list_, sleep_short_period, cc_list, sleep_final

def get_cc_period(distance, SHORT_TM_STAY, CC):
    """
    函数作用: 寻找 LM 序列中 处于两段"睡眠"中间的 "抖动" 状态,该状态可能是停顿中的 吃东西抖动
    也有可能是睡眠过程中的 抽搐抖动
    """
    time_len = len(distance)

    sleep_short_period = np.zeros(len(distance))
    sleep_short_period[distance > 0] = 1

    sleep_list1 = []

    ii = 0
    # 小鼠 每在一个位置停留超过 MIN_TM_SLEEP 秒 暂时认为属于　停留　状态
    while ii < time_len - 1:
        # 睡眠 开始 阶段
        if sleep_short_period[ii] == 0:
            cnt_sleep = 0
            jj = ii + 1
            while jj < time_len:
                if sleep_short_period[jj] == 0:
                    jj += 1
                    cnt_sleep += 1

                else:
                    break
            if cnt_sleep > SHORT_TM_STAY or (cnt_sleep > 10 and ii == 0):
                sleep_list1.append([ii, jj])
            ii = jj
        else:
            ii += 1

    # 过滤 短暂 抽搐 对于两段睡眠中, 若出现小于10s左右的活动,认为 翻身
    cc_list = []
    sleep_short_period_wo_cc = sleep_short_period.copy()
    for tt in range(len(sleep_list1) - 1):
        aweak_start = sleep_list1[tt][1]
        aweak_end = sleep_list1[tt + 1][0]

        ## 活动时间小于一定阈值，有可能属于抽搐情况
        if aweak_end - aweak_start < CC:
            sleep_short_period[aweak_start:aweak_end] = 0
            cc_list.append([aweak_start, aweak_end])
            sleep_short_period_wo_cc[aweak_start:aweak_end] = 0

    return cc_list, sleep_short_period, sleep_short_period_wo_cc

def filter_cc_preiod(sleep_short_period_, SHORT_TM_SLEEP=40):
    time_len = len(sleep_short_period_)
    ii = 0
    # 与之前不同,此处过滤 小于SHORT_TM_SLEEP的片段
    sleep_wo_short = np.ones(time_len)
    short_sleep_list = []
    while ii < time_len - 1:
        # 睡眠 开始 阶段
        if sleep_short_period_[ii] == 0:
            cnt_sleep = 0
            jj = ii + 1
            while jj < time_len:
                if sleep_short_period_[jj] == 0:
                    jj += 1
                    cnt_sleep += 1
                else:
                    break
            if cnt_sleep > SHORT_TM_SLEEP or (cnt_sleep > 10 and ii == 0):
                short_sleep_list.append([ii, jj])
                sleep_wo_short[ii:jj] = 0
            ii = jj
        else:
            ii += 1

    return sleep_wo_short