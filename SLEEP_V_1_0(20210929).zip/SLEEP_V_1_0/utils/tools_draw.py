"""
author:shuai.zhao
function: 图像绘制功能更新
"""
import numpy as np
import matplotlib.pyplot as plt
import os
import itertools

def sec2mini(tt):
    tt = tt.astype(np.int32)
    return np.round(tt / 60, 2)
def save_lm_per_hour_state(sleep_list, save_path, sleep_ts, dav_ts):
    """
    sleep_list: 以列表形式 存储小鼠睡眠时间段，[睡眠起始时间, 睡眠结束时间]
    save_path: txt保存路径
    """
    with open(save_path, 'w') as f:
        f.writelines("################## LM state clc ################## \n")
        if len(sleep_list) == 0:
            f.writelines("Awake period: 0:00:00 to 0:59:59 \n")

        else:
            awake_start = 0
            for sl in sleep_list:
                if sl[0] < 10:
                    tmp = 0
                    sleep_start_min = tmp / 60
                    sleep_start_sec = tmp % 60

                    tmp = int((sl[1]))
                    sleep_end_min = tmp / 60
                    sleep_end_sec = tmp % 60
                    f.writelines("Sleep period: 0:%02d:%02d to 0:%02d:%02d\n" % (sleep_start_min, sleep_start_sec,
                                                                                 sleep_end_min, sleep_end_sec))
                    awake_start = sl[1] + 1
                else:
                    tmp = int(awake_start)
                    awake_start_min = tmp / 60
                    awake_start_sec = tmp % 60

                    tmp = int(sl[0])
                    awake_end_min = tmp / 60
                    awake_end_sec = tmp % 60
                    # 醒着时间段
                    f.writelines("Awake period: 0:%02d:%02d to 0:%02d:%02d\n" % (awake_start_min, awake_start_sec,
                                                                                 awake_end_min, awake_end_sec))

                    tmp = int((sl[0] + 1))
                    sleep_start_min = tmp / 60
                    sleep_start_sec = tmp % 60

                    tmp = int((sl[1]))
                    sleep_end_min = tmp / 60
                    sleep_end_sec = tmp % 60
                    # 睡眠时间段
                    f.writelines("Sleep period: 0:%02d:%02d to 0:%02d:%02d\n" % (sleep_start_min, sleep_start_sec,
                                                                                 sleep_end_min, sleep_end_sec))
                    awake_start = sl[1] + 1

            if np.abs(awake_start - dav_ts) > 10:
                tmp = int(awake_start)
                awake_start_min = tmp / 60
                awake_start_sec = tmp % 60

                tmp = int(dav_ts)
                awake_end_min = tmp / 60
                awake_end_sec = tmp % 60
                f.writelines("Aweak period: 0:%02d:%02d to 0:%02d:%02d\n" % (awake_start_min, awake_start_sec,
                                                                             awake_end_min, awake_end_sec))
        f.writelines("小鼠总睡眠(活动)时长: %2.2f min (%2.2f min)" %
                     (((dav_ts - sleep_ts) / 60.0), sleep_ts / 60.0))
def save_lm_per_hour_Z_png(data, save_dir):
    """
    保存小鼠每个小时之字波形图波形图（Z）
    """
    # 设置横纵坐标的名称以及对应字体格式
    font2 = {'family': 'Times New Roman',
             'weight': 'normal',
             'size': 12,
             }

    ## 将数据 normalize到 3600维度
    data[np.where(data >= 1)] = 1
    # if len(data) != 3600:
    data = np.pad(data, (0, (3600-len(data))), 'constant', constant_values=2)

    assert len(data) == 3600, "ERROR 001>> Dimension Error!"
    data = np.reshape(data, (3, -1)).astype(np.uint8)
    plt.figure(figsize=(20, 10))

    position_video = {0:0, 1:1, 2:0.5}
    mxlabel = {
        0: ["0", "", "", "", "", "5", "", "", "", "", "10", "", "", "", "", "15", "", "", "", "", "20"],
        1: ["20", "",  "", "", "", "25", "", "", "", "", "30", "", "", "", "", "35", "",  "", "", "", "40"],
        2: ["40", "", "", "", "", "45", "", "", "", "", "50", "", "", "", "", "55", "", "", "", "", "60"],
    }
    for ii in range(3):
        # 3个子图，每个子图 20 分钟
        ax = plt.subplot(3, 1, ii+1)

        bg_v = 0
        for i in range(1200-1):
            if data[ii, i] == 0 and data[ii, i+1] == 1:
                plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[0], bg_v-1, i)
                bg_v = i+1
            elif data[ii, i] == 1 and data[ii, i+1] == 0:
                plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v-1, i)
                bg_v = i+1

            # 扩充的表示
            elif data[ii,i] == 0 and data[ii,i+1] == 2:
                # plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v-1, i)
                bg_v = i+1
            elif data[ii,i] == 1 and data[ii,i+1] == 2:
                # plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v-1, i)
                bg_v = i+1

            if i == 1200-1-1:
                plt.hlines(position_video[data[ii, bg_v]], bg_v-1, 1200)

        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.set_ylim(0, 1.8)
        ax.set_xlim((0, 1200+30))
        plt.xticks([x for x in range(0, 1200+30, 60)], mxlabel[ii])
        plt.yticks([0, 1, 1.8], ("Sleep", 'Awake', ""))
        plt.ylabel('STAGE', font2)

    plt.savefig(save_dir)
    plt.close()
def save_lm_day_Z_png(data, save_dir, start_data):
    # 设置横纵坐标的名称以及对应字体格式
    font2 = {'family': 'Times New Roman',
             'weight': 'normal',
             'size': 12,
             }
    each_row = 3600*6
    ext = 100
    skip = 1800

    # 将数据 normalize到 12*3600维度
    data[np.where(data >= 1)] = 1
    data = np.pad(data, (0, (3600*24-len(data))), 'constant', constant_values=2)

    data = np.reshape(data, (4, -1)).astype(np.uint8)

    data = data.astype(np.uint8)

    plt.figure(figsize=(34.4, 12))
    mxlabel = {
        0: ["0", "", "1", "", "2", "", "3", "", "4", "", "5", "", "6"],
        1: ["6", "", "7", "", "8", "","9", "", "10", "", "11", "", "12"],
        2: ["12", "", "13", "", "14", "", "15", "", "16", "", "17", "", "18"],
        3: ["18", "", "19", "", "20", "", "21", "", "22", "","23", "", "24"],
    }
    position_video = {0:0.2, 1:1, 2:0.5}
    for ii in range(4):
        ax = plt.subplot(4, 1, ii + 1)
        # 每4个小时 一个子图
        bg_v = 0
        for i in range(each_row - 1):
            if data[ii, i] == 0 and data[ii, i + 1] == 1:
                plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[0], bg_v - 1, i)
                bg_v = i + 1
            elif data[ii, i] == 1 and data[ii, i + 1] == 0:
                plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v - 1, i)
                bg_v = i + 1

            # 扩充的表示
            elif data[ii, i] == 0 and data[ii, i + 1] == 2:
                # plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v - 1, i)
                bg_v = i + 1
            elif data[ii, i] == 1 and data[ii, i + 1] == 2:
                # plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v - 1, i)
                bg_v = i + 1

            if i == each_row - 1 - 1:
                plt.hlines(position_video[data[ii, bg_v]], bg_v - 1, each_row)
                break

        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.set_ylim(0, 1.8)
        ax.set_xlim((0, each_row + ext))
        plt.xticks([x for x in range(0, each_row + ext, skip)], mxlabel[ii])
        plt.yticks([0, 1, 1.8], ("Sleep", 'Awake', ""))
        plt.ylabel('STAGE', font2)
    plt.savefig(save_dir)
    plt.close()
def save_lm_3days_Z_png(data, save_dir):
    # 设置横纵坐标的名称以及对应字体格式
    font2 = {'family': 'Times New Roman',
             'weight': 'normal',
             'size': 12,
             }
    each_row = 3600*12
    ext = 100
    skip = 3600

    # 将数据 normalize到 12*3600维度
    data[np.where(data >= 1)] = 1
    data = np.pad(data, (0, (each_row*6-len(data))), 'constant', constant_values=2)
    data = np.reshape(data, (6, -1)).astype(np.uint8)

    position_video = {0:0.2, 1:1, 2:0.5}
    mxlabel = {
        0: ["0h", "1", "2", "3", "4", "5", "6", "7","8", "9", "10", "11", "12"],
        1: ["12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24"],
        2: ["0", "1", "2", "3", "4", "5", "6", "7","8", "9", "10", "11", "12"],
        3: ["12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24"],
        4: ["0", "1", "2", "3", "4", "5", "6", "7","8", "9", "10", "11", "12"],
        5: ["12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24h"],
    }

    plt.figure(figsize=(80, 30))
    for ii in range(6):
        ## 时刻
        ax = plt.subplot(6, 1, ii+1)
        bg_v = 0
        for i in range(each_row - 1):
            if data[ii, i] == 0 and data[ii, i + 1] == 1:
                plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[0], bg_v - 1, i)
                bg_v = i + 1
            elif data[ii, i] == 1 and data[ii, i + 1] == 0:
                plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v - 1, i)
                bg_v = i + 1

            # 扩充的表示
            elif data[ii, i] == 0 and data[ii, i + 1] == 2:
                # plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v - 1, i)
                bg_v = i + 1

            elif data[ii, i] == 1 and data[ii, i + 1] == 2:
                # plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v - 1, i)
                bg_v = i + 1

            if i == each_row - 1 - 1:
                plt.hlines(position_video[data[ii, bg_v]], bg_v - 1, each_row)

        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.set_ylim(0, 1.8)
        ax.set_xlim((0, each_row + ext))
        plt.xticks([x for x in range(0, each_row+ext, skip)], mxlabel[ii])
        plt.yticks([0, 1, 1.8], ("Sleep", 'Awake', ""))
        plt.ylabel('STAGE', font2)
    #
    plt.savefig(save_dir)
    plt.close()
def save_lm_day_eeg_video_png(data_eeg, data_video, save_dir):
    # 设置横纵坐标的名称以及对应字体格式
    font2 = {
        'family': 'Times New Roman',
        'weight': 'normal',
        'size': 10,
        }

    each_row = 3600*24
    ext = 100
    skip = 3600

    # 将数据 normalize到 12*3600维度
    data_video[np.where(data_video >= 1)] = 1
    data_video = np.pad(data_video, (0, (each_row-len(data_video))), 'constant', constant_values=2)

    data_video = [data_video[x] for x in range(len(data_video)) if x % 20 == 0]
    eeg_data_add = ["NR"] * 3
    data_eeg = data_eeg[3:] + eeg_data_add
    print(len(data_eeg))

    data_v01 = data_video[:6*180]
    data_v02 = data_video[6*180:12*180]
    data_v03 = data_video[12*180:18*180]
    data_v04 = data_video[18*180:24*180]

    data_e01 = data_eeg[:6*180]
    data_e02 = data_eeg[6*180:12*180]
    data_e03 = data_eeg[12*180:18*180]
    data_e04 = data_eeg[18*180:24*180]

    data_e = [data_e01,data_e02,data_e03,data_e04]
    data_v = [data_v01,data_v02,data_v03,data_v04]
    position_video = {0: 0.2, 1: 1, 2: 0.5}
    position_eeg = {"R": 3, "NR": 2, "W": 1.5}

    plt.figure(figsize=(34.4, 12))
    mxlabel = {
        0: ["0h","", "", "1","", "","2","", "","3","", "","4","", "","5","", "","6"],
        1: ["6", "", "", "7","", "", "8","", "","9","", "","10","", "","11","", "","12"],
        2: ["12","", "", "13","", "","14","", "","15","", "","16","", "","17","", "","18"],
        3: ["18","", "", "19","", "","20","", "","21","", "","22","", "","23","", "","24"]
    }

    for ii in range(4):
        # 时刻
        ax = plt.subplot(4, 1, ii+1)
        bg_v = 0
        bg_e = 0
        for i in range(6 * 180-1):
            if data_v[ii, i] == 0 and data_v[ii, i+1] != 1:
                plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[0], bg_v-1, i)
                bg_v = i+1
            elif data_v[ii, i] == 1 and data_v[ii, i+1] != 0:
                plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v-1, i)
                bg_v = i + 1

            # 扩充的表示
            elif data_v[ii, i] == 0 and data_v[ii, i + 1] == 2:
                # plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v - 1, i)
                bg_v = i + 1

            elif data_v[ii, i] == 1 and data_v[ii, i + 1] == 2:
                # plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v - 1, i)
                bg_v = i + 1

            if i == each_row - 1 - 1:
                plt.hlines(position_video[data_v[ii, bg_v]], bg_v - 1, each_row)

            if i == 6 * 180-1-1:
                plt.hlines(position_video[data_v[ii, bg_v]], bg_v-1, 6 * 180)

            # 由醒着到睡眠
            if data_e[ii][i] == "W" and data_e[ii][i+1] == "NR":
                plt.vlines(i, position_eeg["W"], position_eeg["NR"])
                plt.hlines(position_eeg["W"], bg_e-1, i, linewidth=2)
                bg_e = i+1
            elif data_e[ii][i] == "NR" and data_e[ii][i+1] == "R":      ## 由NR 进入 R
                plt.vlines(i, position_eeg["NR"], position_eeg["R"])
                plt.hlines(position_eeg["NR"], bg_e-1, i, linewidth=2)
                bg_e = i+1
            elif data_e[ii][i] == "R" and data_e[ii][i+1] == "NR":      ## R 进入 NR
                plt.vlines(i, position_eeg["NR"], position_eeg["R"])
                plt.hlines(position_eeg["R"], bg_e-1, i, linewidth=2)
                plt.hlines(position_eeg["R"]-0.1, bg_e-1, i, linewidth=8, colors="r")
                bg_e = i+1
            elif data_e[ii][i] == "NR" and data_e[ii][i+1] == "W":      ## R 进入 NR
                plt.vlines(i, position_eeg["NR"], position_eeg["W"])
                plt.hlines(position_eeg["NR"], bg_e-1, i, linewidth=2)
                bg_e = i+1

            elif data_e[ii][i] == "R" and data_e[ii][i+1] == "W":      ## R 进入 W
                plt.vlines(i, position_eeg["R"], position_eeg["W"])
                plt.hlines(position_eeg["R"], bg_e-1, i, linewidth=2)
                plt.hlines(position_eeg["R"]-0.1, bg_e-1, i, linewidth=8, colors="r")
                bg_e = i+1
            if i == 6 * 180-1-1:
                plt.hlines(position_eeg[data_e[ii][bg_e]], bg_e-1, 6 * 180)


        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.set_ylim(0, 3.5)
        ax.set_xlim((0, 180*6+30))
        plt.xticks([x for x in range(0, 180*6+50, 60)], mxlabel[ii])
        plt.yticks([0, 0.5, 1, 1.5, 2, 3], ("", 'W', 'S', "W", 'NR', 'R'))
        plt.ylabel('STAGE', font2)
    plt.savefig(save_dir)
    plt.close()
def save_lm_per_hour_cid_png(data, save_dir):

    # 设置横纵坐标的名称以及对应字体格式
    font2 = {'family': 'Times New Roman',
             'weight': 'normal',
             'size': 12,
             }
    each_row = 1200
    ext = 100
    skip = 60
    num_fig = 3

    ## 将数据 normalize到 3600维度
    data = np.pad(data, (0, (each_row*3-len(data))), 'constant', constant_values=0)
    assert len(data) == 3600, "ERROR 001>> Dimension Error!"
    data = np.reshape(data, (3, -1))
    mxlabel = {
        0: ["0", "", "", "", "", "5", "", "", "", "", "10", "", "", "", "", "15", "", "", "", "", "20"],
        1: ["20", "",  "", "", "", "25", "", "", "", "", "30", "", "", "", "", "35", "",  "", "", "", "40"],
        2: ["40", "", "", "", "", "45", "", "", "", "", "50", "", "", "", "", "55", "", "", "", "", "60"],
    }
    plt.figure(figsize=(20, 10))
    for i in range(num_fig):
        ax = plt.subplot(3, 1, i + 1)

        plt.plot(data[i])
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.set_ylim(0, 1.2)
        ax.set_xlim((0, 1200+30))
        plt.xticks([x for x in range(0, 1200+30, 60)], mxlabel[i])
        plt.yticks([0, np.max(data), 1.2], ("0", np.max(data), ""))
        plt.ylabel('STAGE', font2)

    plt.savefig(save_dir)
    plt.close()
def save_lm_per_hour_Z_cid_png(data, color, save_dir):
    """
    保存小鼠每个小时之字波形图波形图（Z）
    """
    # 设置横纵坐标的名称以及对应字体格式
    font2 = {'family': 'Times New Roman',
             'weight': 'normal',
             'size': 12,
             }

    ## 将数据 normalize到 3600维度
    # data[np.where(data >= 1)] = 1
    # if len(data) != 3600:
    data = np.pad(data, (0, (3600-len(data))), 'constant', constant_values=2)

    color = color/np.max(color)
    ## 将数据 normalize到 3600维度
    color = np.pad(color, (0, (3600-len(data))), 'constant', constant_values=0)

    assert len(data) == 3600, "ERROR 001>> Dimension Error!"
    data = np.reshape(data, (3, -1))
    color = np.reshape(color, (3, -1))

    plt.figure(figsize=(20, 10))

    position_video = {0:0, 1:1, 2:0.5}
    mxlabel = {
        0: ["0", "", "", "", "", "5", "", "", "", "", "10", "", "", "", "", "15", "", "", "", "", "20"],
        1: ["20", "",  "", "", "", "25", "", "", "", "", "30", "", "", "", "", "35", "",  "", "", "", "40"],
        2: ["40", "", "", "", "", "45", "", "", "", "", "50", "", "", "", "", "55", "", "", "", "", "60"],
    }
    for ii in range(3):
        # 3个子图，每个子图 20 分钟
        ax = plt.subplot(3, 1, ii+1)

        bg_v = 0
        for i in range(1200-1):
            if data[ii, i] == 0 and data[ii, i+1] == 1:
                plt.vlines(i, position_video[1], position_video[0])
                # plt.hlines(position_video[0], bg_v-1, i)
                # print(bg_v, i)
                plt.plot(range(bg_v, i), color[ii, bg_v:i], color='b')
                bg_v = i+1
            elif data[ii, i] == 1 and data[ii, i+1] == 0:
                plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v, i)
                plt.plot(range(bg_v, i), color[ii, bg_v:i], color='r')

                bg_v = i+1

            # 扩充的表示
            elif data[ii,i] == 0 and data[ii,i+1] == 2:
                # plt.vlines(i, position_video[1], position_video[0])
                # plt.hlines(position_video[1], bg_v, i)
                plt.plot(range(bg_v, i), color[ii, bg_v:i], color='b')
                bg_v = i+1
            elif data[ii,i] == 1 and data[ii,i+1] == 2:
                # plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v, i)
                plt.plot(range(bg_v, i), color[ii, bg_v:i], color='r')
                bg_v = i+1

            if i == 1200-1-1 and data[ii,i] == 1:
                # plt.plot(range(bg_v, i), color[ii, bg_v:i], color='b')
                plt.hlines(position_video[data[ii, bg_v]], bg_v, 1200)
                plt.plot(range(bg_v, i), color[ii, bg_v:i], color='r')

            if i == 1200-1-1 and data[ii,i] == 0:
                plt.plot(range(bg_v, i), color[ii, bg_v:i], color='b')
                # plt.hlines(position_video[data[ii, bg_v]], bg_v, 1200)

        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.set_ylim(0, 1.8)
        ax.set_xlim((0, 1200+30))
        plt.xticks([x for x in range(0, 1200+30, 60)], mxlabel[ii])
        plt.yticks([0, 1, 1.8], ("Sleep", 'Awake', ""))
        plt.ylabel('STAGE', font2)

    plt.savefig(save_dir)
    plt.close()
def save_video_eeg_png_day(cfg, data_sleep, data_eeg, data_color, save_dir, ch, side="left"):
    png_save_name = os.path.join(save_dir,'%s_%s.png' % (ch, side))
    ll = 3600*24
    rlen = int(ll / 4)
    step = int(0.5*3600)
    """
    保存小鼠每个小时之字波形图波形图（Z）包含 color iou distance eeg sleep等
    """
    # 设置横纵坐标的名称以及对应字体格式
    font2 = {
        'family': 'Times New Roman',
        'weight': 'normal',
        'size': 12,
        }
    data_color = data_color/np.max(data_color)
    data_color = np.pad(data_color, (0, (ll-len(data_color))), 'constant', constant_values=0)

    assert len(data_sleep) == ll, "ERROR 002>> Dimension Error!{}".format(len(data_sleep))

    eeg_data_add = ["NR"] * 3
    data_eeg_20 = data_eeg[3:] + eeg_data_add
    data_eeg = list(itertools.chain.from_iterable(itertools.repeat(x, 20) for x in data_eeg_20))

    data_sleep = np.reshape(data_sleep, (4, -1))
    data_color = np.reshape(data_color, (4, -1))
    data_eeg = np.reshape(data_eeg, (4, -1))

    # print(data_sleep.shape, data_color.shape, data_eeg.shape, data_eeg.shape)
    position_video = {0: 0.2, 1: 1, 2: 0.5}
    position_eeg = {"R": 3, "NR": 2, "W": 1.5}
    mxlabel = {
        0: ["0", "", "1", "", "2", "", "3", "", "4", "", "5", "", "6"],
        1: ["6", "", "7", "", "8", "", "8", "", "10", "", "11", "", "12"],
        2: ["12", "", "13", "", "14", "", "15", "", "16", "", "17", "", "18"],
        3: ["18", "", "19", "", "20", "", "21", "", "22", "", "23", "", "24"],
    }
    plt.figure(figsize=(34.4, 12))

    for ii in range(4):
        # 3个子图，每个子图 20 分钟
        ax = plt.subplot(4, 1, ii+1)

        bg_v = 0
        bg_e = 0
        for i in range(rlen-1):
            if data_sleep[ii, i] == 0 and data_sleep[ii, i+1] == 1:
                plt.hlines(position_video[0], bg_v, i)
                plt.vlines(i, position_video[1], position_video[0])
                plt.plot(range(bg_v, i), data_color[ii, bg_v:i], color='b')
                bg_v = i
            elif data_sleep[ii, i] == 1 and data_sleep[ii, i+1] == 0:
                plt.vlines(i, position_video[1], position_video[0])
                plt.hlines(position_video[1], bg_v, i)
                plt.plot(range(bg_v, i), data_color[ii, bg_v:i], color='r')
                bg_v = i

            # 扩充的表示
            elif data_sleep[ii,i] == 0 and data_sleep[ii,i+1] == 2:
                plt.hlines(position_video[0], bg_v, i)
                plt.vlines(i, position_video[1], position_video[0])
                plt.plot(range(bg_v, i), data_color[ii, bg_v:i], color='b')
                bg_v = i
            elif data_sleep[ii,i] == 1 and data_sleep[ii,i+1] == 2:
                plt.hlines(position_video[1], bg_v, i)
                plt.vlines(i, position_video[1], position_video[2])
                plt.plot(range(bg_v, i), data_color[ii, bg_v:i], color='r')
                bg_v = i

            if i == rlen-1-1 and data_sleep[ii,i] == 1:
                plt.hlines(position_video[data_sleep[ii, bg_v+1]], bg_v, rlen)
                plt.plot(range(bg_v, i), data_color[ii, bg_v:i], color='r')

            if i == rlen-1-1 and data_sleep[ii,i] == 0:
                plt.hlines(position_video[data_sleep[ii, bg_v+1]], bg_v, rlen)
                plt.plot(range(bg_v, i), data_color[ii, bg_v:i], color='b')

            # 由醒着到睡眠
            if data_eeg[ii,i] == "W" and data_eeg[ii,i+1] == "NR":
                plt.vlines(i, position_eeg["W"], position_eeg["NR"])
                plt.hlines(position_eeg["W"], bg_e-1, i, linewidth=2)
                bg_e = i
            elif data_eeg[ii,i] == "NR" and data_eeg[ii,i+1] == "R":      ## 由NR 进入 R
                plt.vlines(i, position_eeg["NR"], position_eeg["R"])
                plt.hlines(position_eeg["NR"], bg_e, i, linewidth=2)
                bg_e = i
            elif data_eeg[ii,i] == "R" and data_eeg[ii,i+1] == "NR":      ## R 进入 NR
                plt.vlines(i, position_eeg["NR"], position_eeg["R"])
                plt.hlines(position_eeg["R"], bg_e, i, linewidth=2)
                plt.hlines(position_eeg["R"]-0.1, bg_e, i, linewidth=8, colors="r")
                bg_e = i
            elif data_eeg[ii,i] == "NR" and data_eeg[ii,i+1] == "W":      ## R 进入 NR
                plt.vlines(i, position_eeg["NR"], position_eeg["W"])
                plt.hlines(position_eeg["NR"], bg_e, i, linewidth=2)
                bg_e = i

            elif data_eeg[ii,i] == "R" and data_eeg[ii,i+1] == "W":      ## R 进入 W
                plt.vlines(i, position_eeg["R"], position_eeg["W"])
                plt.hlines(position_eeg["R"], bg_e, i, linewidth=2)
                plt.hlines(position_eeg["R"]-0.1, bg_e, i, linewidth=8, colors="r")
                bg_e = i
            if i == rlen-1-1:
                plt.hlines(position_eeg[data_eeg[ii][bg_e+1]], bg_e-1, rlen)


        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.set_ylim(0, 3.5)
        ax.set_xlim((0, rlen+30))

        plt.xticks([x for x in range(0, rlen+30, step)], mxlabel[ii])
        plt.yticks([0, 0.2, 1, 1.5, 2, 3], ("", 'W', 'S', "W", 'NR', 'R'))
        plt.ylabel('STAGE', font2)

    plt.savefig(png_save_name)
    plt.close()
def save_video_png(cfg, sleep22, sleep23, color_np, analysis1_dir, name_list, side="left"):

    hours = cfg["DAYS"]*24
    for j in range(hours):
        name = name_list[j]

        sleep2 = sleep22[j * 3600:(j + 1) * 3600]
        sleep3 = sleep23[j * 3600:(j + 1) * 3600]
        color = color_np[j * 3600:(j + 1) * 3600]

        day = j // 24
        hour = j % 24
        print("已保存 第%d天，%d小时图像..." % (day+1, hour+1))

        png_save = os.path.join(analysis1_dir, '%s_%s2.png' % (name, side))
        save_lm_per_hour_Z_cid_png(sleep2, color, png_save)

        png_save = os.path.join(analysis1_dir, '%s_%s3.png' % (name, side))
        save_lm_per_hour_Z_cid_png(sleep3, color, png_save)
def save_video_eeg_png(cfg, sleep20, sleep21, sleep22, sleep23, color_np, eeg_np, analysis1_dir, name_list, side="left"):

    hours = cfg["DAYS"]*24
    for j in range(hours):
        name = name_list[j]

        sleep0 = sleep20[j * 3600:(j + 1) * 3600]
        sleep1 = sleep21[j * 3600:(j + 1) * 3600]
        sleep2 = sleep22[j * 3600:(j + 1) * 3600]
        sleep3 = sleep23[j * 3600:(j + 1) * 3600]
        color = color_np[j * 3600:(j + 1) * 3600]
        eeg = eeg_np[j*180:(j+1)*180]
        day = j // 24
        hour = j % 24

        png_save = os.path.join(analysis1_dir, '%s_%s2.png' % (name, side))
        save_lm_per_hour_Z_cid_eeg_png(sleep3, color,eeg,png_save)

        png_save = os.path.join(analysis1_dir, '%s_%s3.png' % (name, side))
        save_lm_per_hour_Z_cid_eeg_png(sleep3, color,eeg,png_save)
        print("已保存 第%d天，%d小时图像..." % (day+1, hour+1), png_save)
def get_sleep_wake_time(cfg, sleep_np, sleep_wake_np):
    hours = cfg["DAYS"]*24
    for j in range(hours):
        sleep3 = sleep_np[j * 3600:(j + 1) * 3600]
        sleep_awake_hour = np.sum(sleep3)  ## 活动时长
        day = j // 24
        hour = j % 24
        print("完成 第%d天，%d小时视频分析..." % (day+1, hour+1))
        sleep_wake_np[day, hour, 1] = float((sleep_awake_hour / 60.0))
        sleep_wake_np[day, hour, 0] = float((60 - sleep_awake_hour / 60.0))
