# *_* coding:utf-8 *_*

import csv
import os
import numpy as np
import pandas as pd
import argparse

def concate_csvs(csv_dir, csv_save):

    files = list(set([file[0:file.rfind("_")] for file in os.listdir(csv_dir)]))
    files.sort(key = lambda x: int(x[2:]))  ##文件名按数字排序

    assert len(files) > 1, "Can't find csvfiles!!!"
    ch_data = []
    for fcsv in files:
        lcsv_path = os.path.join(csv_dir, fcsv+"_left.csv")
        if os.path.isfile(lcsv_path):
            with open(lcsv_path, 'r') as csvfile:
                reader = csv.reader(csvfile)
                lavg = []
                for i, row in enumerate(reader):
                    if i == 0:
                        continue
                    lavg.append([row[-2], row[-1]])
                lavg = np.array(lavg).astype(np.float)

        rcsv_path = os.path.join(csv_dir, fcsv+"_right.csv")
        if os.path.isfile(rcsv_path):
            with open(rcsv_path, 'r') as csvfile:
                reader = csv.reader(csvfile)
                ravg = []
                for i, row in enumerate(reader):
                    if i == 0:
                        continue
                    ravg.append([row[-2], row[-1]])
                ravg = np.array(ravg).astype(np.float)

        ch = np.hstack((lavg, ravg))
        ch_data.append(ch)

    keys = ["NIBS"]
    for file in files:
        keys.extend(["%s"%file.upper(), "%s"%file.upper()])

    data1 = [["ZT"] + ["L", "R"]*len(files)]

    data2=[]
    for i in range(24):
        ## 睡眠数据
        tmp_data = [i]
        for dd in ch_data:
            tmp_data.extend([dd[i][0], dd[i][2]])
        data2.append(tmp_data)

    data3 = ["Light sleep time"]
    for dd in ch_data:
        data3.extend([dd[24][0], dd[24][2]])
    data4 = ["Dark sleep time"]
    for dd in ch_data:
        data4.extend([dd[25][0], dd[25][2]])
    data5 = ["Total sleep time"]
    for dd in ch_data:
        data5.extend([dd[26][0], dd[26][2]])
    data3 = [data3]
    data4 = [data4]
    data5 = [data5]
    # print(data3, data4, data5)

    data6=[]
    for i in range(24):
        ## 睡眠数据
        tmp_data = [i]
        for dd in ch_data:
            tmp_data.extend([dd[i][1], dd[i][3]])
        data6.append(tmp_data)

    data7 = ["Light wake time"]
    for dd in ch_data:
        data7.extend([dd[24][1], dd[24][3]])
    data8 = ["Dark wake time"]
    for dd in ch_data:
        data8.extend([dd[25][1], dd[25][3]])
    data9 = ["Total wake time"]
    for dd in ch_data:
        data9.extend([dd[26][1], dd[26][3]])
    data7 = [data7]
    data8 = [data8]
    data9 = [data9]

    data = data1+data2+data3+data4+data5+data6+data7+data8+data9

    data_frame = pd.DataFrame(columns=keys, data=data)
    data_frame.to_csv(csv_save, sep = ',', index = False)


if __name__ =="__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument('--dir', required=True, type=str)
    config = parser.parse_args()

    csv_save_name = config.dir +  "\\merage.csv"
    concate_csvs(config.dir, csv_save_name)