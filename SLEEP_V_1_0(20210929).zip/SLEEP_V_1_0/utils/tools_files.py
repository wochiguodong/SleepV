# *_* coding:utf-8 *_*
"""
author:shuai.zhao
function: 文件处理
"""
import os
import datetime
import numpy as np
import csv
import pandas as pd

def get_dav_info(file):
    """
    返回文件相关信息
    """
    Ex, ch, start, end, _ = file.split("_")
    return Ex, ch


def get_names(start_date, ex, ch, hours=72):
    name_list = []
    # Y-m-d H M S
    dt = '%s-%s-%s %s:%s:%s' % (start_date[:4], start_date[4:6], start_date[6:8], start_date[8:10], start_date[10:12], start_date[12:14])
    start_date_normal = datetime.datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
    for i in range(hours):
        start = "%d%02d%02d%02d0000"%(start_date_normal.year, start_date_normal.month, start_date_normal.day, start_date_normal.hour)
        start_date_normal = start_date_normal + datetime.timedelta(hours=1)
        end = "%d%02d%02d%02d0000"%(start_date_normal.year, start_date_normal.month, start_date_normal.day, start_date_normal.hour)
        tmp_name = "%s_%s_%s_%s"%(ex, ch, start, end)
        # print(tmp_name)
        name_list.append(tmp_name)
    return name_list

def get_nps(lm_featuer, days):
    sleep_np = []
    distance_np = []
    color_np = []
    iou_np = []
    hours = days*24
    for i in range(hours):
        # 移动距离         pred差值  iou差值   pix差值
        # distance_left, lmaxpred, lmaxiou, lmaxerr_pix

        distance = np.ones(3600)
        color = np.zeros(3600)
        iou = np.zeros(3600)
        sleep = np.zeros(3600)
        # distance color iou predict
        if i == hours-1:
            feature_hour = np.zeros((3600, 4))
            # print("&&&&&&&&&&& ", len(lm_featuer[i*3600:]))
            if len(lm_featuer[i*3600:]) > 3600:
                feature_hour[:, :] = lm_featuer[i*3600:(1+i)*3600]
            else:
                feature_hour[:len(lm_featuer[i*3600:]), :] = lm_featuer[i * 3600:]
        else:
            feature_hour = lm_featuer[i*3600:(i+1)*3600]
        # print(feature_hour.shape)
        feature_hour[np.where(feature_hour[:, 0] == -1)] = 0

        feature_hour_1 = feature_hour[:, 1]
        feature_hour_2 = feature_hour[:, 2]
        feature_hour_3 = feature_hour[:, 3]
        
        # 根据特征信息判断小鼠是否活动
        sleep[feature_hour_2 < 0.01] = 0
        sleep[(feature_hour_1 > 5)] = 1
        sleep[(feature_hour_2 >= 0.05)] = 1  ## 100% 运动
        sleep[feature_hour_1 < 3] = 0

        feature_hour_2[feature_hour_2 > 1] = 1
        feature_hour_3[feature_hour_3 > 1] = 1

        distance[:len(feature_hour[:, 2])] = feature_hour[:, 0]
        iou[:len(feature_hour[:, 2])] = feature_hour[:, 1]
        color[:len(feature_hour[:, 2])] = feature_hour[:, 2]
        ##
        feature_hour[:, 2] = feature_hour_2
        feature_hour[:, 3] = feature_hour_3

        distance[:len(feature_hour[:, 2])] = feature_hour[:, 0]
        iou[:len(feature_hour[:, 2])] = feature_hour[:, 2]
        color[:len(feature_hour[:, 2])] = feature_hour[:, 1]

        sleep_np.extend(sleep)
        distance_np.extend(distance)
        color_np.extend(color)
        iou_np.extend(iou)
    # print(np.sum(sleep_np))
    return sleep_np, distance_np, color_np, iou_np


def sec2min(tt):
    tt = int(tt)
    return "%.2f" % (tt / 60)


## 更新 可保存N天csv文件
def save_analysis_days_csv(save_dir, ch, days, data, side):

    csv_save_name = os.path.join(save_dir,
                                 '%s_%s.csv' % (ch, side))
    pddata = []
    if days == 1:
        keys = ["Hour"] + ["S", "W"]
        for i in range(24):
            pddata.append([i, data[0, i, 0], data[0, i, 1]])

        pddata.append(["Light S/W time", np.sum(data[0, 0:12, 0]), np.sum(data[0,0:12, 1])]) # 白天总和
        pddata.append(["Dark S/W time", np.sum(data[0, 12:, 0]), np.sum(data[0,12:, 1])]) # 夜晚总和
        pddata.append(["Total S/W time", np.sum(data[0, :, 0]), np.sum(data[0, :, 1])]) # 白天+夜晚总和

    else:
        keys = ["Hour"] + ["S", "W"]*days +["AS", "AW"]
        for i in range(24):
            tmp_row = [i]
            for day in range(days):
                tmp_row.extend([data[day, i, 0], data[day, i, 1]])
            tmp_row.extend([np.sum(data[:, i, 0])/days, np.sum(data[:, i, 1])/days])
            pddata.append(tmp_row)
        ## 总和统计
        tmp_row1 = ["Light S/W time"]
        tmp_row2 = ["Dark S/W time"]
        tmp_row3 = ["Total S/W time"]
        for day in range(days):
            tmp_row1.extend([np.sum(data[day, 0:12, 0]), np.sum(data[day, 0:12, 1])])
            tmp_row2.extend([np.sum(data[day, 12:, 0]), np.sum(data[day, 12:, 1])])
            tmp_row3.extend([np.sum(data[day, :, 0]), np.sum(data[day, :, 1])])

        tmp_row1.extend([np.sum(data[:, 0:12, 0]) / days, np.sum(data[:, 0:12, 1]) / days])
        tmp_row2.extend([np.sum(data[:, 12:, 0]) / days, np.sum(data[:, 12:, 1]) / days])
        tmp_row3.extend([np.sum(data[:, :, 0]) / days, np.sum(data[:, :, 1]) / days])

        pddata.append(tmp_row1)  # 白天总和
        pddata.append(tmp_row2)  # 夜晚总和
        pddata.append(tmp_row3)  # 白天+夜晚总和

    data_frame = pd.DataFrame(columns=keys, data=pddata)
    data_frame.to_csv(csv_save_name, sep = ',', index = False, float_format='%.3f')


def loadTXT(txt_root, files, side='left'):
    feature = None
    for i, name in enumerate(files):
        # 移动距离         pred差值  iou差值   pix差值
        # distance_left, lmaxpred, lmaxiou, lmaxerr_pix
        # 单个视频分析
        filename = "%s\\%s_%s.txt" % (txt_root, name, side)
        if not os.path.isfile(filename):
            print("Can't find %s\n" % filename)
            return
        data = np.loadtxt(filename)
        # print(filename, data.shape)
        # assert 4 == data.shape[1], "Feature shape error"

        if i == 0:
            feature = data
        else:
            if len(data) > 0:
                feature = np.vstack((feature, data))
    return feature


# 读取excel文件
def excel(csv_file):
    data = []  #创建空list
    with open(csv_file, 'r') as f:
        reader = csv.reader(f)
        for i, row in enumerate(reader):
            if i == 0:
                continue
            data.append(row[0:2])
    return data


def concate_csvs(csv_dir, name):
    files = list(set([file.split("_")[0] for file in os.listdir(csv_dir) if file.startswith("ch")]))
    files.sort(key=lambda x: int(x.split("_")[0][2:]))  ##文件名按数字排序
    assert len(files) > 1, "Can't find csvfiles!!!"
    ch_data = []

    for fcsv in files:
        lcsv_path = os.path.join(csv_dir, fcsv + "_left.csv")
        with open(lcsv_path, 'r') as csvfile:
            reader = csv.reader(csvfile)
            lavg = []
            for i, row in enumerate(reader):
                if i == 0:
                    continue
                lavg.append([row[-2], row[-1]])
            lavg = np.array(lavg).astype(np.float)

        rcsv_path = os.path.join(csv_dir, fcsv + "_right.csv")
        assert os.path.isfile(rcsv_path), "Can't find {}".format(rcsv_path)
        with open(rcsv_path, 'r') as csvfile:
            reader = csv.reader(csvfile)
            ravg = []
            for i, row in enumerate(reader):
                if i == 0:
                    continue
                ravg.append([row[-2], row[-1]])
            ravg = np.array(ravg).astype(np.float)

        ch = np.hstack((lavg, ravg))
        ch_data.append(ch)

    keys = ["NIBS"]

    for file in files:
        keys.extend(["%s" % file.upper(), "%s" % file.upper()])

    data1 = [["ZT"] + ["L", "R"] * len(files)]

    data2 = []
    for i in range(24):
        ## 睡眠数据
        tmp_data = [i]
        for dd in ch_data:
            tmp_data.extend([dd[i][0], dd[i][2]])
        data2.append(tmp_data)

    data3 = ["Light sleep time"]
    for dd in ch_data:
        data3.extend([dd[24][0], dd[24][2]])
    data4 = ["Dark sleep time"]
    for dd in ch_data:
        data4.extend([dd[25][0], dd[25][2]])
    data5 = ["Total sleep time"]
    for dd in ch_data:
        data5.extend([dd[26][0], dd[26][2]])
    data3 = [data3]
    data4 = [data4]
    data5 = [data5]

    data6 = []
    for i in range(24):
        ## 睡眠数据
        tmp_data = [i]
        for dd in ch_data:
            tmp_data.extend([dd[i][1], dd[i][3]])
        data6.append(tmp_data)

    data7 = ["Light wake time"]
    for dd in ch_data:
        data7.extend([dd[24][1], dd[24][3]])
    data8 = ["Dark wake time"]
    for dd in ch_data:
        data8.extend([dd[25][1], dd[25][3]])
    data9 = ["Total wake time"]
    for dd in ch_data:
        data9.extend([dd[26][1], dd[26][3]])
    data7 = [data7]
    data8 = [data8]
    data9 = [data9]

    data = data1 + data2 + data3 + data4 + data5 + data6 + data7 + data8 + data9

    csv_save_path = os.path.join(csv_dir, name)
    data_frame = pd.DataFrame(columns=keys, data=data)
    data_frame.to_csv(csv_save_path, sep=',', index=False)

def concate_csvs_SD(csv_dir, name):
    files = list(set([file.split("_")[0] for file in os.listdir(csv_dir) if file.startswith("ch")]))
    files.sort(key=lambda x: int(x.split("_")[0][2:]))  ##文件名按数字排序
    assert len(files) > 1, "Can't find csvfiles!!!"
    ch_data = []

    for fcsv in files:
        lcsv_path = os.path.join(csv_dir, fcsv + "_left_SD.csv")
        with open(lcsv_path, 'r') as csvfile:
            reader = csv.reader(csvfile)
            lavg = []
            for i, row in enumerate(reader):
                if i == 0:
                    continue
                lavg.append([row[-2], row[-1]])
            lavg = np.array(lavg).astype(np.float)

        rcsv_path = os.path.join(csv_dir, fcsv + "_right_SD.csv")
        assert os.path.isfile(rcsv_path), "Can't find {}".format(rcsv_path)
        with open(rcsv_path, 'r') as csvfile:
            reader = csv.reader(csvfile)
            ravg = []
            for i, row in enumerate(reader):
                if i == 0:
                    continue
                ravg.append([row[-2], row[-1]])
            ravg = np.array(ravg).astype(np.float)

        ch = np.hstack((lavg, ravg))
        ch_data.append(ch)
    keys = ["SD"]
    for file in files:
        keys.extend(["%s" % file.upper(), "%s" % file.upper()])

    data1 = [["ZT"] + ["L", "R"] * len(files)]

    data2 = []
    for i in range(24):
        ## 睡眠数据
        tmp_data = [i]
        for dd in ch_data:
            tmp_data.extend([dd[i][0], dd[i][2]])
        data2.append(tmp_data)

    data6 = []
    for i in range(24):
        ## 睡眠数据
        tmp_data = [i]
        for dd in ch_data:
            tmp_data.extend([dd[i][1], dd[i][3]])
        data6.append(tmp_data)
        
    data = data1 + data2 + data6

    csv_save_path = os.path.join(csv_dir, name)
    data_frame = pd.DataFrame(columns=keys, data=data)
    data_frame.to_csv(csv_save_path, sep=',', index=False)

def save_analysis_SD_csv(save_dir, ch, data, side, start=7):

    csv_save_name = os.path.join(save_dir,
                                 '%s_%s_SD.csv' % (ch, side))
    # if start == 7:
    #     data[0, 2:8, 0] = 0
    #     data[0,2:8, 1] = 60
    # elif start == 9:
    #     data[0,:6, 0] = 0
    #     data[0,:6, 1] = 60

    pddata = []

    keys = ["Hour"] + ["S", "W"]
    for i in range(24):
        pddata.append([i, data[0, i, 0], data[0, i, 1]])

    data_frame = pd.DataFrame(columns=keys, data=pddata)
    data_frame.to_csv(csv_save_name, sep = ',', index = False, float_format='%.3f')

