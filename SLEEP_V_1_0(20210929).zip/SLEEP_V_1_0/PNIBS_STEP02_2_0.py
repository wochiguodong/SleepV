"""
author:shuai.zhao
email: shuai.zhao@ia.ac.cn
"""

from utils.tools_draw import get_sleep_wake_time, save_video_png
from utils.tools_filter import get_sleep_list
from utils.tools_files import get_names, get_dav_info, loadTXT, save_analysis_days_csv, get_nps, concate_csvs
import json
import argparse
import os
import numpy as np

def get_sleep_nps(lm_feature, cfg):
    sleep_np, distance_np, color_np, iou_np = get_nps(lm_feature, cfg["DAYS"])
    sleep_4hour_np = np.reshape(sleep_np, (6*cfg["DAYS"], -1))        # 每一行代表4小时数据
    color_4hour_np = np.reshape(color_np, (6*cfg["DAYS"], -1))        # 每一行代表4小时数据
    iou_4hour_np  = np.reshape(iou_np, (6*cfg["DAYS"], -1))        # 每一行代表4小时数据
    sleep20, sleep21, sleep22, sleep23 = [], [], [], []
    for i in range(6*cfg["DAYS"]):
        # 20s返回结果/结合长睡眠过滤/删除小幅度/对20s结果进行部分过滤5s
        # new_distance, sleep_list, sleep_all, sleep_final
        sleep40, sleep41, sleep42, sleep43 = get_sleep_list(sleep_4hour_np[i], cfg)
        sleep20.extend(sleep40)
        sleep21.extend(sleep41)
        sleep22.extend(sleep42)
        sleep23.extend(sleep43)
    return sleep20, sleep21, sleep22, sleep23, color_np


def main(cfg, analysis_dir1, analysis_dir2):

    files = list(set([file[0:file.rfind("_")] for file in os.listdir(cfg["SAVE_TXT"])]))
    files.sort()

    ffiles = []
    for file in files:
        _, ch, s1, s2 = file.split("_")
        # if s1[-4:] == "0000" and s2[-4:] == "0000" and s1>=cfg["DATA_START"] and s2 <= cfg["DATA_END"]:
        if s1 >= cfg["DATA_START"] and s2 <= cfg["DATA_END"]:
            ffiles.append(file)
    # print(ffiles)
    assert len(ffiles) >= cfg["DAYS"] * 24, "请检查待测试日期是否正确！ %d, ch: %s" % (len(ffiles), ch)
    lm_feature_left = loadTXT(cfg["SAVE_TXT"], ffiles, "left")
    lm_feature_right = loadTXT(cfg["SAVE_TXT"], ffiles, "right")

    total_hour = lm_feature_left.shape[0]//3600
    total_min = lm_feature_left.shape[0]%3600/60

    print("待检测小鼠视频个数为:  %d, 总计: %d天" % (len(ffiles), cfg["DAYS"]))
    print("检测到测小鼠视频时长:  [%d小时 %d分钟]" % (total_hour, total_min))
    print("################################## AVI INFO ###################################")
    print("ROOT_DIR: %s" % cfg["SAVE_TXT"])
    print("SAVE_TXT_DIR1: %s" % analysis_dir1)
    print("SAVE_TXT_DIR2: %s" % analysis_dir2)
    print("SHORT_PERIOD: %d" % cfg["SHORT_TM_SLEEP"])
    print("CC: %d" % cfg["CC"])
    print("###############################################################################")

    ## 左右小鼠每个小时的睡眠情况
    left_day_sleep_wake = np.zeros((cfg["DAYS"], 24, 2)) - 1
    right_day_sleep_wake = np.zeros((cfg["DAYS"], 24, 2)) - 1

    # 获得视频录制时间信息
    # start_year, start_month, start_day, start_hour, start_min, ch
    ex, ch = get_dav_info(ffiles[0] + "_left.txt")
    name_list = get_names(cfg["DATA_START"], ex, ch)

    lsleep20, lsleep21, lsleep22, lsleep23, lcolor = get_sleep_nps(lm_feature_left, cfg)
    assert len(lsleep23)==len(lcolor), "Error in dimension!!!"
    get_sleep_wake_time(cfg, lsleep23, left_day_sleep_wake)
    save_analysis_days_csv(analysis_dir2, ch,int(cfg["DAYS"]),left_day_sleep_wake, "left")
    # save_video_png(cfg, lsleep22, lsleep23, lcolor, analysis_dir1, name_list, "left")
    rsleep20, rsleep21, rsleep22, rsleep23, rcolor = get_sleep_nps(lm_feature_right, cfg)
    get_sleep_wake_time(cfg, rsleep23, right_day_sleep_wake)
    save_analysis_days_csv(analysis_dir2, ch,int(cfg["DAYS"]),right_day_sleep_wake, "right")
    # save_video_png(cfg, rsleep22, rsleep23, rcolor, analysis_dir1, name_list, "right")


if __name__ == '__main__':
    ################################################# 参数设置 ##########################################################
    parser = argparse.ArgumentParser()
    parser.add_argument('--cfg', required=True, type=str)
    config = parser.parse_args()

    if not os.path.isfile(config.cfg):
        print("Not correct cfg file!")
        exit()

    with open(config.cfg, 'r') as f:
        cfg = json.load(f)

    ROOT_DIR = cfg["SAVE_TXT"]                  ## txt 文件保存路径
    dirs = sorted(os.listdir(ROOT_DIR))           ## chs
    
    ## 数据分析文件保存路径
    save_dir = [st for st in cfg["SAVE_TXT"].split("\\") if len(st)>0]
    print(save_dir)
    analysis_dir1 = cfg["SAVE_ANALYSIS1"] + "\\" + save_dir[-1]
    analysis_dir2 = cfg["SAVE_ANALYSIS2"] + "\\" + save_dir[-1]
    # 对于每个ch通道，分别分析
    for dir in dirs:
        ch_analysis = analysis_dir1 + "\\" + dir
        if not os.path.exists(ch_analysis):
            os.makedirs(ch_analysis)
        if not os.path.exists(analysis_dir2):
            os.makedirs(analysis_dir2)
        cfg["SAVE_TXT"] = os.path.join(ROOT_DIR, dir)
        main(cfg, ch_analysis, analysis_dir2)

    ## 保存拼接后的csv文件
    concate_csvs(analysis_dir2, save_dir[-1]+".csv")
