#coding=utf-8
import os
import ctypes
import argparse
import json
import time
from multiprocessing import Pool, Value, Lock


"""
加入多线程处理机制
"""
lock = Lock()

def process(opts):
    dav_path, save_txt, save_avi, isDraw  = opts
    print("开始文件检测:", dav_path)

    ts = time.time()
    lock.acquire()
    lib = ctypes.cdll.LoadLibrary("tools\\NIBSLIB01.dll")
    lock.release()
    lib.eMFeature(bytes(dav_path, encoding='utf8'), bytes(save_txt, encoding='utf8'),\
                  bytes(save_avi, encoding='utf8'), bytes(isDraw, encoding='utf8'))
    print ("保存可视化文件:%s; 总耗时：%5.2f(min)"%(dav_path, (time.time()-ts)/60 ))

def main(cfg):
    dav_list = os.listdir(cfg["ROOT_DIR"])
    ## 获得{通道:dav文件}键值对 字典
    ch_name_dict = splitByCh(dav_list)

    dav_txt_dir = []
    for ch in ch_name_dict.keys():
        ## 保存文件路径
        save_txt = os.path.join(cfg["SAVE_TXT"], ch)
        save_avi = os.path.join(cfg["SAVE_AVI"], ch)
        isDraw = cfg["DRAW"]
        if not os.path.exists(save_txt):
            os.makedirs(save_txt)
        if not os.path.exists(save_avi) and isDraw == "TRUE":
            os.makedirs(save_avi)
        for dav_file in ch_name_dict[ch]:
            dav_path = os.path.join(cfg["ROOT_DIR"], dav_file)
            dav_txt_dir.append((dav_path, save_txt, save_avi, isDraw))
    
    print(dav_txt_dir)
    return dav_txt_dir
    
## 所有dav文件都在一个文件夹下，实现按通道返回
def splitByCh(dav_files):

    ch_name_dic = {}    
    chs = []
    for file in dav_files:
        _, ch, start_date, end_date = file.split("_")
        start_year = int(start_date[:4])
        start_month = int(start_date[4:6])
        start_day = int(start_date[6:8])
        start_hour = int(start_date[8:10])
        if ch in ch_name_dic.keys():
            ch_name_dic[ch].append(file)
        else:
            ch_name_dic[ch]=[file]
    return ch_name_dic


if __name__=='__main__':

    ################################################# 参数设置 ##########################################################
    parser = argparse.ArgumentParser()

    parser.add_argument('--cfg', required=True,
                        type=str)
    config = parser.parse_args()
    if not os.path.isfile(config.cfg):
        print("Not correct cfg file!")
        exit()
    with open(config.cfg, 'r') as f:
        cfg = json.load(f)

    OPTS = main(cfg)

    pool = Pool(34)
    pool.map(process, OPTS)
    pool.close()#关闭进程池，不再接受新的进程
    pool.join()#主进程阻塞等待子进程的退出
